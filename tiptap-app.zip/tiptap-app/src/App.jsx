import React from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import { StarterKit } from '@tiptap/starter-kit';
import BoldExtension from './BoldExtension'; 

const App = () => {
  const editor = useEditor({
    extensions: [
      StarterKit, 
      BoldExtension,
    ],
    content: '<p>Hello, <strong>world!</strong></p>',
  });

  return (
    <div>
      <button onClick={() => editor.commands.toggleBold()}>Toggle Bold</button>
      <EditorContent editor={editor} />
    </div>
  );
};

export default App;
