import { Extension } from '@tiptap/core';

const BoldExtension = Extension.create({
  name: 'bold',

  addCommands() {
    return {
      toggleBold: () => ({ commands }) => {
        return commands.toggleMark('bold');
      },
    };
  },

  addMark() {
    return {
      bold: {
        parseHTML() {
          return [{ tag: 'strong' }];
        },
        renderHTML() {
          return ['strong', 0];
        },
      },
    };
  },
});

export default BoldExtension;
